package com.example.peter.lab3;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.wifi.hotspot2.pps.HomeSp;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static android.location.Location.convert;

public class Goods_info extends AppCompatActivity {

    private ImageView pic;
    private ImageView back;
    private ImageView star;
    private TextView name;
    private TextView price;
    private TextView info;


    private Goods goods;
    private ImageView buy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);

        findView();
        initialData();
        setListener();
    }

    private void findView(){
        setContentView(R.layout.detail);
        pic = (ImageView) findViewById(R.id.pic);
        back = (ImageView) findViewById(R.id.back);
        star = (ImageView) findViewById(R.id.star);
        name = (TextView) findViewById(R.id.title);
        price = (TextView) findViewById(R.id.price);
        info = (TextView) findViewById(R.id.info);
        buy = (ImageView) findViewById(R.id.cart);
    }

    private void initialData(){

        goods = (Goods) getIntent().getExtras().get("goods");
        if(goods != null){
            pic.setImageResource(goods.getImageId());
            name.setText(goods.getName());
            price.setText(goods.getPrice());
            info.setText(goods.getInfomation());
        }
        star.setTag(0);
    }

    private void setListener(){
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                finish();
            }
        });

        star.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if((Integer) view.getTag()==0){
                    view.setBackgroundResource(R.drawable.full_star);
                    view.setTag(1);
                }
                else{
                    view.setBackgroundResource(R.drawable.empty_star);
                    view.setTag(0);
                }
            }
        });

        buy.setClickable(true);
        buy.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                setResult(1,new Intent(Goods_info.this,MainActivity.class).putExtra("goods",goods));
                Toast.makeText(Goods_info.this,"商品已加入到购物车",Toast.LENGTH_SHORT).show();
            }
        });
    }


}

