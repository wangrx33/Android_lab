package com.example.peter.lab3;


import java.io.Serializable;

public class Goods implements Serializable {

    private int imageId;
    private String name;
    private String price;
    private String info;

    public  Goods(int image, String name, String price, String info){
        this.imageId = image;
        this.name = name;
        this.price = price;
        this.info = info;
    }

    public String getFirstLetter(){
        String first;
        first = name.substring(0,1);
        return first;
    }

    public int getImageId(){

        return imageId;
    }

    public String getName(){
        return name;
    }

    public String getPrice(){
        return price;
    }

    public String getInfomation(){
        return info;
    }

}
