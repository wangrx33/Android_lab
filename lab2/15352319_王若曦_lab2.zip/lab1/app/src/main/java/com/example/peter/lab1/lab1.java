package com.example.peter.lab1;

import android.content.DialogInterface;
import android.preference.DialogPreference;
import android.support.annotation.IdRes;

import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import static com.example.peter.lab1.R.id.button;
import static com.example.peter.lab1.R.id.sno;

public class lab1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab1);
        Button button1 = (Button) findViewById(button);

    }
        //button.setOnClickListener()
        //public abstract class LayoutInflater extends Object
    public void clicktp(View v){
        AlertDialog.Builder builder = new AlertDialog.Builder(lab1.this);
                builder.setTitle("上传头像");
        //LayoutInflater inflater = getLayoutInflater();
        //final View layout = inflater.inflate(R.layout.dialog, null);//获取自定义布局
        //builder.setView(layout);
        final String[] select = {"拍摄", "从相册选择"};
        //    设置一个下拉的列表选择项
        builder.setItems(select, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                Toast.makeText(lab1.this, "您选择了" + select[which], Toast.LENGTH_SHORT).show();
            }
        });
        /*builder.setPositiveButton("拍摄", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(lab1.this, "拍你妈卖批，去吃瓜瓜", Toast.LENGTH_SHORT).show();
                    }
                });*/
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Toast.makeText(lab1.this, "您选择了取消" , Toast.LENGTH_SHORT).show();
                    }
                });
                /*builder.setNeutralButton("取消", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                       Toast.makeText(lab1.this, "您选择了取消" , Toast.LENGTH_SHORT).show();
                 }
                });*/
                builder.show();
    }
    int mod = 0;
    public void clickxs(View v){
        mod = 0;
        Snackbar.make(v,"您选择了学生",Snackbar.LENGTH_SHORT)
                .setAction("确定",new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
    public void clickjzg(View v){
        mod = 1;
        Snackbar.make(v,"您选择了教职工",Snackbar.LENGTH_SHORT)
                .setAction("确定",new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    public void clickdl(View v){
        TextInputLayout sno = (TextInputLayout) findViewById(R.id.sno);
        TextInputLayout pwd = (TextInputLayout) findViewById(R.id.pwd);
        String username =sno.getEditText().getText().toString();
        String password =pwd.getEditText().getText().toString();
        if(TextUtils.isEmpty(username)){
            sno.setError("学号不能为空");
            sno.setErrorEnabled(true);
        }
        else{
            sno.setErrorEnabled(false);
            if(TextUtils.isEmpty(password)){
                pwd.setError("密码不能为空");
                pwd.setErrorEnabled(true);
            }
            else{
                pwd.setErrorEnabled(false);
                if(TextUtils.equals(username,"123456")){
                    if(TextUtils.equals(password,"6666")){
                        Snackbar.make(v,"登陆成功",Snackbar.LENGTH_SHORT)
                                .setAction("确定",new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .show();
                    }
                    else {
                        Snackbar.make(v,"学号或密码错误",Snackbar.LENGTH_SHORT)
                                .setAction("确定",new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .show();
                    }
                }
                else{
                    Snackbar.make(v,"学号或密码错误",Snackbar.LENGTH_SHORT)
                            .setAction("确定",new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                                }
                            })
                            .show();
                }
            }

        }


    }

    public void clickzc(View v){
        if(mod == 0){
            Snackbar.make(v,"学生注册功能尚未启用",Snackbar.LENGTH_SHORT)
                    .setAction("确定",new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
        }
        else if(mod == 1){
            Toast.makeText(lab1.this, "教职工的注册功能尚未启用" , Toast.LENGTH_SHORT).show();
            /*Snackbar.make(v,"教职工注册功能尚未启用",Snackbar.LENGTH_SHORT)
                    .setAction("确定",new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(lab1.this, "Snackbar的确定按钮被点击了" , Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();*/
        }
    }



}
